package com.example.healthsystem;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fragment.ClassifyFragment;
import com.example.fragment.HomePageFragment;
import com.example.fragment.MimeFragment;
import com.example.fragment.NutritionFragment;


/**
 * Created by Coder-pig on 2015/8/28 0028.
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //UI Object
    private TextView top_text;
    private TextView homePageText;
    private TextView classifyText;
    private TextView hotText;
    private TextView nutritionQueryText;
    private TextView mimeText;
    private FrameLayout ly_content;

    //Fragment Object
    private Fragment fg1, fg2, fg3, fg4, fg5;
    private FragmentManager fManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        fManager = getFragmentManager();
        bindViews();
        homePageText.performClick();   //模拟一次点击，既进去后选择第一项
    }

    //UI组件初始化与事件绑定
    private void bindViews() {
        top_text = findViewById(R.id.top_text);
        homePageText = findViewById(R.id.home_page_text);
        classifyText = findViewById(R.id.classify_text);
        hotText = findViewById(R.id.hot_text);
        nutritionQueryText = findViewById(R.id.nutrition_query_text);
        mimeText = findViewById(R.id.mime_text);
        ly_content = findViewById(R.id.ly_content);
        homePageText.setOnClickListener(this);
        classifyText.setOnClickListener(this);
        hotText.setOnClickListener(this);
        nutritionQueryText.setOnClickListener(this);
        mimeText.setOnClickListener(this);
    }

    //重置所有文本的选中状态
    private void setSelected() {
        homePageText.setSelected(false);
        classifyText.setSelected(false);
        hotText.setSelected(false);
        nutritionQueryText.setSelected(false);
        mimeText.setSelected(false);
    }

    //隐藏所有Fragment
    private void hideAllFragment(FragmentTransaction fragmentTransaction) {
        if (fg1 != null) fragmentTransaction.hide(fg1);
        if (fg2 != null) fragmentTransaction.hide(fg2);
        if (fg3 != null) fragmentTransaction.hide(fg3);
        if (fg4 != null) fragmentTransaction.hide(fg4);
        if (fg5 != null) fragmentTransaction.hide(fg5);
    }


    @Override
    public void onClick(View v) {
        FragmentTransaction fTransaction = fManager.beginTransaction();
        hideAllFragment(fTransaction);
        switch (v.getId()) {
            case R.id.home_page_text:
                setSelected();
                homePageText.setSelected(true);
                if (fg1 == null) {
                    fg1 = new HomePageFragment();
                    fTransaction.add(R.id.ly_content, fg1);
                }
                fTransaction.addToBackStack(null);
                fTransaction.show(fg1);
                break;
            case R.id.classify_text:
                setSelected();
                classifyText.setSelected(true);
                if (fg2 == null) {
                    fg2 = new ClassifyFragment();
                    fTransaction.add(R.id.ly_content, fg2);
                }
                fTransaction.addToBackStack(null);
                fTransaction.show(fg2);
                break;
            case R.id.hot_text:
                setSelected();
                hotText.setSelected(true);
                if (fg3 == null) {
                    fg3 = new ClassifyFragment();
                    fTransaction.add(R.id.ly_content, fg3);
                }
                fTransaction.addToBackStack(null);
                fTransaction.show(fg3);
                break;
            case R.id.nutrition_query_text:
                setSelected();
                nutritionQueryText.setSelected(true);
                if (fg4 == null) {
                    fg4 = new NutritionFragment();
                    fTransaction.add(R.id.ly_content, fg4);
                }
                fTransaction.addToBackStack(null);
                fTransaction.show(fg4);
                break;
            case R.id.mime_text:
                setSelected();
                mimeText.setSelected(true);
                if (fg5 == null) {
                    fg5 = new MimeFragment();
                    fTransaction.add(R.id.ly_content, fg5);
                }
                fTransaction.addToBackStack(null);
                fTransaction.show(fg5);

                break;
        }
        fTransaction.commit();
    }
}
