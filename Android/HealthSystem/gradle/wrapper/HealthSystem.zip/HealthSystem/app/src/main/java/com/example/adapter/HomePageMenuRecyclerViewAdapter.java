package com.example.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.entity.HomePageMenu;
import com.example.healthsystem.R;

import java.util.List;

public class HomePageMenuRecyclerViewAdapter extends RecyclerView.Adapter<HomePageMenuRecyclerViewAdapter.RecyclerViewHolder> {

    private List<HomePageMenu> menus;
    /**
     * 页数下标，从0开始，第几页
     */
    private int index;
    /**
     * 每页显示最大条目个数
     */
    private int maxPageSize;
    private Context context;
    private final LayoutInflater layoutInflater;

    public HomePageMenuRecyclerViewAdapter(Context context, List<HomePageMenu> menus, int index, int maxPageSize) {
        this.menus = menus;
        this.index = index;
        this.maxPageSize = maxPageSize;
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new RecyclerViewHolder(layoutInflater.inflate(R.layout.home_page_menu, null));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        final int pos = position + index * maxPageSize;
        holder.textView.setText(menus.get(pos).getMenuName());
        holder.imageView.setImageResource(menus.get(pos).getMenuImage());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomePageMenu menu = menus.get(pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return menus.size() > (index + 1) * maxPageSize ? maxPageSize : (menus.size() - index * maxPageSize);
    }

    @Override
    public long getItemId(int position) {
        return position + index * maxPageSize;
    }

    class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private TextView textView;
        private ImageView imageView;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.home_page_menu_text);
            imageView = itemView.findViewById(R.id.home_page_menu_image);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 4);
            itemView.setLayoutParams(layoutParams);
        }
    }
}
