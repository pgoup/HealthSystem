package com.example.fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.support.v4.view.*;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;



import com.example.adapter.FoodAdapter;
import com.example.adapter.HomeMenuViewAdapter;
import com.example.adapter.HomePageMenuRecyclerViewAdapter;
import com.example.entity.Food;
import com.example.entity.HomePageMenu;
import com.example.healthsystem.R;
import com.example.utils.ScreenUtils;

import java.util.*;

public class HomePageFragment extends Fragment {

    private static final int HOME_PAGE_MENU_SIZE = 10;

    /**
     * 显示各个食物的view
     */
    public   recyclerRootView;
    /**
     * 食物集
     */
    private List<Food> foods = new ArrayList<>();
    /**
     * 显示menu的viewpager
     */
    private ViewPager viewPager;
    /**
     * home_page的framelayout
     */
    private FrameLayout homePageLayout;
    /**
     * 菜单集合
     */
    private List<HomePageMenu> menus = new ArrayList<>();
    private FoodAdapter foodAdapter;
    private HomeMenuViewAdapter viewAdapter;
    private HomePageMenuRecyclerViewAdapter recyclerViewAdapter;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.home_page_fragment, container, false);
        recyclerRootView = view.findViewById(R.id.recycler_root_view);
        viewPager = view.findViewById(R.id.view_pager);
        /**初始化数据*/
        initData();
        /**初始化recyclerView*/
        initRecyclerView();

        return view;
    }

    private void initRecyclerView() {

        LinearLayout.LayoutParams layoutParams12 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int) ((float) ScreenUtils.getScreenWidth() / 2.0f));
        /*LinearLayout.LayoutParams entrancelayoutParams = new LinearLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, (int) ((float) ScreenUtils.getScreenWidth() / 2.0f + 70));
        homePageLayout.setLayoutParams(entrancelayoutParams);*/
        /*viewPager.setLayoutParams(layoutParams12);*/
        //首页菜单分页

        LayoutInflater inflater = LayoutInflater.from(getActivity());
        //将RecyclerView放至ViewPager中：
        int pageSize = HOME_PAGE_MENU_SIZE;
        //一共的页数等于 总数/每页数量，并取整。
        int pageCount = (int) Math.ceil(menus.size() * 1.0 / pageSize);
        List<View> viewList = new ArrayList<>();
        for (int index = 0; index < pageCount; index++) {
            //每个页面都是inflate出一个新实例
            RecyclerView recyclerView = (RecyclerView) inflater.inflate(R.layout.home_page_menu_recycler_view, viewPager, false);
            //recyclerView.setLayoutParams(layoutParams12);
            recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 5));
            HomePageMenuRecyclerViewAdapter entranceAdapter = new HomePageMenuRecyclerViewAdapter(getActivity(), menus, index, HOME_PAGE_MENU_SIZE);
            recyclerView.setAdapter(entranceAdapter);
            viewList.add(recyclerView);
        }

        HomeMenuViewAdapter adapter = new HomeMenuViewAdapter(viewList);
        viewPager.setAdapter(adapter);
        viewPager.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {

            }
        });

        foodAdapter = new FoodAdapter(getActivity(), foods);
        /**给recyclerRootView设置适配器*/
        recyclerRootView.setAdapter(foodAdapter);
        /** 设置layoutManager，可以设置显示效果，是线性布局，grid布局还是瀑布流布局
         * 参数是：上下文，列表方向（横向还是纵向），是否倒序
         * */
        recyclerRootView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        /**设置item的分割线*/
        recyclerRootView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));
        foodAdapter.setOnItemClickListener(new FoodAdapter.OnItemClickListener() {
            @Override
            public void OnItemClick(View view, Food data) {
                Toast.makeText(getActivity(), "点击出发事件", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void initData() {
        for (int i = 0; i < 100; i++) {
            Food food = new Food("" + i, R.mipmap.image1);
            foods.add(food);
        }
        for (int i = 0; i < 12; i++) {
            HomePageMenu menu = new HomePageMenu("" + i, R.mipmap.image1);
            menus.add(menu);
        }
    }
}
